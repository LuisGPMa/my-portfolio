	>-Bote os arquivos com os códigos para montar/desmontar no
mesmo diretório que o .jar
	>-O output será colocado nos arquivos "assembly_output.txt" ou "disassembly_output.txt";
	>-Formatação para a motagem:
		*Pode usar ambas nomenclaturas para os registradores.
		*Pode usar espaços.
		*Pode usar "0x" na frente de valores em hexa
		*Não usar valores em decimal
		*Botar o .text, o .globl e o main: cada um em sua linha.

PS.: Eu levei horas para conseguir rodar no meu Windows o .jar, e mesmo assim eu só consegui executar ele
usando o seguinte comando "java -jar montador_e_desmontador.jar". Não consegui executar o .jar com clique duplo.
Caso não consiga rodar o .jar nem com clique duplo nem através do comando, me avisa que corrijo e te mando tudo 
de novo.
